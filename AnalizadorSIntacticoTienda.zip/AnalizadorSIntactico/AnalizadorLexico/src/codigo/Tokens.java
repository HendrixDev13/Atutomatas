/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

/**
 *
 * @author Charly Ponce
 */
public enum Tokens {
  error,
 Nombrecliente,
 CodigoCliente,
 Producto,
 separador,
 Precio,
 Seccion,
 Linea

}
