/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gps;

import static gps.Tokens.Menor;
import static gps.Tokens.PalabraInicio;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Files;
import java.util.logging.Level;
import java.util.logging.Logger;
import java_cup.runtime.Symbol;
import javax.swing.JFileChooser;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Charly Ponce
 */
public class FrmPrincipal extends javax.swing.JFrame {

    Object[] fila = new Object[4];

    /**
     * Creates new form FrmPrincipal
     */
    public FrmPrincipal() {
        initComponents();
        this.setLocationRelativeTo(null);
         jFileChooser1.setVisible(false);
    }

    private void analizarLexico() throws IOException {
        DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel();

        int cont = 1;

        String expr = (String) txtResultado.getText();
        Lexer lexer = new Lexer(new StringReader(expr));
        String resultado = "LINEA " + cont + "\t\tSIMBOLO\n";
        while (true) {
            Tokens token = lexer.yylex();
            if (token == null) {
                //txtAnalizarLex.setText(resultado);
                jTable1.setModel(modelo);
                return;
            }
            switch (token) {
                case Linea:
                    cont++;
                    resultado += "LINEA " + cont + "\n";
                    break;
                case HorasTime:
                    resultado += "  <INICIO>\t\t" + lexer.lexeme + "\n";
                    fila[0] = "HORA";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;
                case Fechas:
                    resultado += "  <FIN>\t" + lexer.lexeme + "\n";
                    fila[0] = "FECHA";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;
                case Letra:
                    resultado += "  <Hombre>\t" + lexer.lexeme + "\n";
                    fila[0] = "LETRA";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;
                case Valor:
                    resultado += "  <Mujer>\t" + lexer.lexeme + "\n";
                    fila[0] = "VALOR";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;
                case Mayor:
                    resultado += "  <Nombre>\t\t" + lexer.lexeme + "\n";
                    fila[0] = "MAYOR";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;
                case Menor:
                    resultado += "  <Mesa>\t\t" + lexer.lexeme + "\n";
                    fila[0] = "MENOR";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;
               case Tiempo:
                    resultado += "  <Mesa>\t\t" + lexer.lexeme + "\n";
                    fila[0] = "TIEMPO";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;
                case Igual:
                    resultado += "  <Mesa>\t\t" + lexer.lexeme + "\n";
                    fila[0] = "IGUAL";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;
                case Longitud:
                    resultado += "  <Mesa>\t\t" + lexer.lexeme + "\n";
                    fila[0] = "LONGITUD";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;               
                case Latitud:
                    resultado += "  <Mesa>\t\t" + lexer.lexeme + "\n";
                    fila[0] = "LATITUD";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;
                case PalabraFinal:
                    resultado += "  <Mesa>\t\t" + lexer.lexeme + "\n";
                    fila[0] = "FINAL";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;
                case PalabraInicio:
                    resultado += "  <Mesa>\t\t" + lexer.lexeme + "\n";
                    fila[0] = "INICIO";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;
                 case Coma:
                    resultado += "  <Mesa>\t\t" + lexer.lexeme + "\n";
                    fila[0] = "COMA";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;
                case CodigoPostal:
                    resultado += "  <Mesa>\t\t" + lexer.lexeme + "\n";
                    fila[0] = "CODIGOPOSTAL";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;
                case TelNumero:
                    resultado += "  <Mesa>\t\t" + lexer.lexeme + "\n";
                    fila[0] = "TEL";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;
                    
                case ERROR:
                    resultado += "  <Simbolo no definido>\n";
                    fila[0] = "No definido";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;
                default:
                    resultado += "  < " + lexer.lexeme + " >\n";
                    fila[0] = "Errr";
                    fila[1] = lexer.lexeme;
                    modelo.addRow(fila);
                    break;
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtResultado = new javax.swing.JTextArea();
        btnAnalizarLex = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtAnalizarSin = new javax.swing.JTextArea();
        btnAnalizarSin = new javax.swing.JButton();
        btn_limpiar = new javax.swing.JButton();
        btncargar = new javax.swing.JButton();
        jFileChooser1 = new javax.swing.JFileChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 255, 153));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Analizador Lexico", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 18))); // NOI18N
        jPanel1.setToolTipText("G");
        jPanel1.setInheritsPopupMenu(true);

        txtResultado.setColumns(20);
        txtResultado.setRows(5);
        jScrollPane1.setViewportView(txtResultado);

        btnAnalizarLex.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnAnalizarLex.setText("LEXICO");
        btnAnalizarLex.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnalizarLexActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Token", "Lexema"
            }
        ));
        jScrollPane4.setViewportView(jTable1);

        txtAnalizarSin.setEditable(false);
        txtAnalizarSin.setColumns(20);
        txtAnalizarSin.setRows(5);
        jScrollPane3.setViewportView(txtAnalizarSin);

        btnAnalizarSin.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnAnalizarSin.setText("SINTACTICO");
        btnAnalizarSin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnalizarSinActionPerformed(evt);
            }
        });

        btn_limpiar.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        btn_limpiar.setText("LIMPIAR");
        btn_limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_limpiarActionPerformed(evt);
            }
        });

        btncargar.setFont(new java.awt.Font("Bahnschrift", 0, 18)); // NOI18N
        btncargar.setText("CARGAR ARCHIVO");
        btncargar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncargarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(46, 46, 46)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnAnalizarLex, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(256, 256, 256)
                                .addComponent(btn_limpiar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btncargar))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnAnalizarSin, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 510, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jFileChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAnalizarLex)
                    .addComponent(btn_limpiar)
                    .addComponent(btncargar))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(172, 172, 172)
                        .addComponent(btnAnalizarSin))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(145, 145, 145)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(46, 46, 46)
                .addComponent(jFileChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        jPanel1.getAccessibleContext().setAccessibleName("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAnalizarLexActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnalizarLexActionPerformed
        try {
            analizarLexico();
        } catch (IOException ex) {
            Logger.getLogger(FrmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnAnalizarLexActionPerformed

    private void btnAnalizarSinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnalizarSinActionPerformed
        // TODO add your handling code here:
        String ST = txtResultado.getText();
        Sintax s = new Sintax(new gps.LexerCup(new StringReader(ST)));

        try {
            s.parse();
            txtAnalizarSin.setText("Analisis realizado correctamente");
            txtAnalizarSin.setForeground(new Color(25, 111, 61));
        } catch (Exception ex) {
            Symbol sym = s.getS();
            txtAnalizarSin.setText("Error de sintaxis. Linea: " + (sym.right + 1) + " Columna: " + (sym.left + 1) + ", Texto: \"" + sym.value + "\"");
            txtAnalizarSin.setForeground(Color.red);
        }
    }//GEN-LAST:event_btnAnalizarSinActionPerformed

    private void btn_limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_limpiarActionPerformed
       txtAnalizarSin.setText("");
        txtResultado.setText("");
         DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel(); 
    modelo.setRowCount(0);
    }//GEN-LAST:event_btn_limpiarActionPerformed

    private void btncargarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncargarActionPerformed
       
           jFileChooser1.setVisible(true);
        int returnValue = jFileChooser1.showOpenDialog(this);

        // Verificar si el usuario seleccionó un archivo
        if (returnValue == javax.swing.JFileChooser.APPROVE_OPTION) {
            File archivoSeleccionado = jFileChooser1.getSelectedFile();

            try {

                BufferedReader reader = new BufferedReader(new FileReader(archivoSeleccionado));
                StringBuilder contenidoArchivo = new StringBuilder();
                String linea;
                while ((linea = reader.readLine()) != null) {
                    contenidoArchivo.append(linea).append("\n");
                }
                reader.close();

                txtResultado.setText(contenidoArchivo.toString());
            } catch (FileNotFoundException ex) {
                Logger.getLogger(FrmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                txtResultado.setText("Archivo no encontrado: " + ex.getMessage());
            } catch (IOException ex) {
                Logger.getLogger(FrmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                txtResultado.setText("Error al leer el archivo: " + ex.getMessage());
            }
        } else {
            txtResultado.setText("No se seleccionó ningún archivo.");
        }
        
        
    }//GEN-LAST:event_btncargarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAnalizarLex;
    private javax.swing.JButton btnAnalizarSin;
    private javax.swing.JButton btn_limpiar;
    private javax.swing.JButton btncargar;
    private javax.swing.JFileChooser jFileChooser1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea txtAnalizarSin;
    private javax.swing.JTextArea txtResultado;
    // End of variables declaration//GEN-END:variables
}
